# Support Ticket Management — Angular Front End

Angular front end for the Support Ticket Management Spring Boot REST API (COOP Angular assignment). Lists, searches, filters by category, views, creates, updates and deletes support tickets, with login and role-based access.

## Prerequisites

- Node.js 18+ and npm
- Angular CLI (`npm install -g @angular/cli`) — or just use the local `npx ng` / the `npm start` script below, no global install required
- The backend running locally (see "Start the backend" below) and a MySQL server for it to connect to

## How to start the backend

1. Create a MySQL database named `support_ticket_db` (or update `spring.datasource.url` in `support-ticket-management/src/main/resources/application.properties` to match your setup).
2. From the `support-ticket-management` folder, run:
   ```
   ./mvnw spring-boot:run
   ```
3. The API starts on **http://localhost:8081**. On first startup it seeds three test accounts into the database automatically (see below) — no manual SQL needed.

## How to run the front end

```
npm install
npm start
```

This runs `ng serve` and opens the app on **http://localhost:4200**. The backend must already be running on port 8081 (CORS is configured on the backend specifically for `http://localhost:4200`).

## API base URL and environment configuration

The API base URL is never hardcoded in a component or service — it's read from the Angular environment files:

- `src/environments/environment.ts` → used by `ng serve` (development)
- `src/environments/environment.prod.ts` → used by `ng build` (production)

Both currently point to `http://localhost:8081/api`. Change `apiUrl` there if your backend runs elsewhere.

## Test users and their roles

Authentication is database-backed (see `AppUser` / `CustomUserDetailsService` on the backend) and seeded automatically on first backend startup:

| Username | Password | Role     |
|----------|----------|----------|
| employee | 1234     | EMPLOYEE |
| manager  | 1234     | MANAGER  |
| admin    | 1234     | ADMIN    |

- **EMPLOYEE** — can view, search and filter tickets.
- **MANAGER** — everything EMPLOYEE can do, plus create and edit tickets.
- **ADMIN** — everything MANAGER can do, plus delete tickets.

The app authenticates via HTTP Basic on every request (the backend has no separate token endpoint). Logging in sends the entered credentials to `GET /api/auth/me`; a successful response confirms the credentials and returns the role, which is cached in `sessionStorage` so the session survives a page refresh.

## Application routes

| Path                          | Component            | Access                     |
|--------------------------------|-----------------------|-----------------------------|
| `/`                            | redirects to `/tickets` | —                          |
| `/tickets`                     | TicketListComponent   | EMPLOYEE, MANAGER, ADMIN   |
| `/tickets/category/:category`  | TicketListComponent   | EMPLOYEE, MANAGER, ADMIN   |
| `/tickets/search/:keyword`     | TicketListComponent   | EMPLOYEE, MANAGER, ADMIN   |
| `/tickets/detail/:id`          | TicketDetailComponent | EMPLOYEE, MANAGER, ADMIN   |
| `/tickets/add`                 | TicketFormComponent   | MANAGER, ADMIN             |
| `/tickets/edit/:id`            | TicketFormComponent   | MANAGER, ADMIN             |
| `/login`                       | LoginComponent        | Public                     |
| `/access-denied`               | AccessDeniedComponent | Any logged-in user         |
| `**`                           | PageNotFoundComponent | Public                     |

An unauthenticated user hitting any protected route is redirected to `/login`. A logged-in user without the required role is redirected to `/access-denied`.

## Notes on what was fixed on the backend

The Spring Boot project this front end connects to needed several fixes to satisfy the requirements of this assignment (paged Get-All, a search endpoint, CORS, database-backed roles, etc.) — see the top-level project README / delivery notes for the full list.

## Production build

```
npm run build
```

Output goes to `dist/support-ticket-frontend`. `node_modules` and `dist` are excluded from the submission via `.gitignore`.
