export const environment = {
  production: true,
  // Replace with the deployed backend URL before shipping a production build.
  apiUrl: 'http://localhost:8081/api'
};
