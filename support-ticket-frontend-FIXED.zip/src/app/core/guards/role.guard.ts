import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../models/user.model';

/**
 * Reads the allowed roles from the route's `data.roles` array
 * (see app.routes.ts). Must run after authGuard, which already
 * redirects unauthenticated users to /login.
 */
export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const allowedRoles = (route.data['roles'] as UserRole[]) ?? [];

  if (allowedRoles.length === 0 || auth.hasRole(...allowedRoles)) {
    return true;
  }

  return router.createUrlTree(['/access-denied']);
};
