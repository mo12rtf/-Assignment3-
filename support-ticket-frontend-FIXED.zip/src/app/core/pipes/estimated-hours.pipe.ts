import { Pipe, PipeTransform } from '@angular/core';

/**
 * Formats a raw hour count into a readable label, e.g. 1 -> "1 hr",
 * 8 -> "8 hrs". Used on the ticket detail page.
 */
@Pipe({
  name: 'estimatedHours',
  standalone: true
})
export class EstimatedHoursPipe implements PipeTransform {
  transform(value: number | null | undefined): string {
    if (value == null) {
      return '—';
    }
    return `${value} hr${value === 1 ? '' : 's'}`;
  }
}
