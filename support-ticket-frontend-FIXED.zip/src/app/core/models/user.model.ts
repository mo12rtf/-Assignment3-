export type UserRole = 'EMPLOYEE' | 'MANAGER' | 'ADMIN';

export interface CurrentUser {
  username: string;
  role: UserRole;
}
