/** Matches com.ejada.support_ticket_management.dto.PagedResponse<T> exactly. */
export interface PagedResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}
