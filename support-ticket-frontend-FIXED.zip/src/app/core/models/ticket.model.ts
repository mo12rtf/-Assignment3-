export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';

/** Matches com.ejada.support_ticket_management.entity.SupportTicket exactly. */
export interface SupportTicket {
  id?: number;
  title: string;
  category: string;
  estimatedHours: number;
  priority: TicketPriority | string;
  status: TicketStatus | string;
  active: boolean;
  code: string;
}

export const TICKET_CATEGORIES: string[] = [
  'Hardware',
  'Software',
  'Network',
  'Account',
  'Other'
];

export const TICKET_PRIORITIES: TicketPriority[] = ['LOW', 'MEDIUM', 'HIGH', 'URGENT'];

export const TICKET_STATUSES: TicketStatus[] = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];
