import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const notifications = inject(NotificationService);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      switch (error.status) {
        case 401:
          // Bad or expired credentials: drop the session and send the
          // person back to the login page.
          auth.logout();
          router.navigate(['/login']);
          notifications.error('Please sign in to continue.');
          break;

        case 403:
          notifications.error(
            error.error?.message ?? 'You do not have permission to perform this action.'
          );
          break;

        case 404:
          notifications.error(error.error?.message ?? 'The requested record was not found.');
          break;

        case 400:
          notifications.error(error.error?.message ?? 'The submitted data is invalid.');
          break;

        default:
          notifications.error('Something went wrong. Please try again.');
      }

      return throwError(() => error);
    })
  );
};
