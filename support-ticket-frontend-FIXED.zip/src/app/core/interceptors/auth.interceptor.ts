import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const authHeader = auth.getAuthHeader();

  if (!authHeader) {
    return next(req);
  }

  const authorizedReq = req.clone({
    setHeaders: { Authorization: authHeader }
  });

  return next(authorizedReq);
};
