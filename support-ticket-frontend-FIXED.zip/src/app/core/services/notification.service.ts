import { Injectable, signal } from '@angular/core';

export interface AppNotification {
  message: string;
  kind: 'success' | 'error' | 'info';
}

@Injectable({ providedIn: 'root' })
export class NotificationService {
  readonly current = signal<AppNotification | null>(null);
  private timeoutId: ReturnType<typeof setTimeout> | undefined;

  show(message: string, kind: AppNotification['kind'] = 'info'): void {
    this.current.set({ message, kind });
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
    this.timeoutId = setTimeout(() => this.current.set(null), 5000);
  }

  success(message: string): void {
    this.show(message, 'success');
  }

  error(message: string): void {
    this.show(message, 'error');
  }

  dismiss(): void {
    this.current.set(null);
  }
}
