import { HttpClient } from '@angular/common/http';
import { Injectable, computed, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CurrentUser, UserRole } from '../models/user.model';

const STORAGE_KEY = 'stm.session';

interface StoredSession {
  authHeader: string;
  user: CurrentUser;
}

/**
 * The backend authenticates every request via HTTP Basic (see
 * SecurityConfig on the API). There is no token endpoint, so "logging in"
 * here means: build the Basic Authorization header from the entered
 * credentials, send it to GET /api/auth/me, and treat a 200 response as a
 * successful login (the body tells us the role). The header + role are
 * cached in sessionStorage so the session survives a page refresh but not
 * a closed tab, which is the right trade-off for credentials kept only in
 * memory/browser storage rather than a real token.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly currentUserSignal = signal<CurrentUser | null>(this.restoreUser());
  private authHeader: string | null = this.restoreAuthHeader();

  readonly currentUser = computed(() => this.currentUserSignal());
  readonly isLoggedIn = computed(() => this.currentUserSignal() !== null);

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<CurrentUser> {
    const header = 'Basic ' + btoa(`${username}:${password}`);

    return this.http
      .get<CurrentUser>(`${environment.apiUrl}/auth/me`, {
        headers: { Authorization: header }
      })
      .pipe(
        tap((user) => {
          this.authHeader = header;
          this.currentUserSignal.set(user);
          this.persist(header, user);
        })
      );
  }

  logout(): void {
    this.authHeader = null;
    this.currentUserSignal.set(null);
    sessionStorage.removeItem(STORAGE_KEY);
  }

  getAuthHeader(): string | null {
    return this.authHeader;
  }

  hasRole(...roles: UserRole[]): boolean {
    const user = this.currentUserSignal();
    return !!user && roles.includes(user.role);
  }

  private persist(authHeader: string, user: CurrentUser): void {
    const session: StoredSession = { authHeader, user };
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  }

  private restoreAuthHeader(): string | null {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return null;
    }
    try {
      return (JSON.parse(raw) as StoredSession).authHeader;
    } catch {
      return null;
    }
  }

  private restoreUser(): CurrentUser | null {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return null;
    }
    try {
      return (JSON.parse(raw) as StoredSession).user;
    } catch {
      return null;
    }
  }
}
