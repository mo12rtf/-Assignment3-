import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PagedResponse } from '../models/paged-response.model';
import { SupportTicket } from '../models/ticket.model';

@Injectable({ providedIn: 'root' })
export class TicketService {
  private readonly baseUrl = `${environment.apiUrl}/tickets`;

  constructor(private http: HttpClient) {}

  getItems(page: number, size: number): Observable<PagedResponse<SupportTicket>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<PagedResponse<SupportTicket>>(this.baseUrl, { params });
  }

  getItemById(id: number): Observable<SupportTicket> {
    return this.http.get<SupportTicket>(`${this.baseUrl}/${id}`);
  }

  getItemsByCategory(
    category: string,
    page: number,
    size: number
  ): Observable<PagedResponse<SupportTicket>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<PagedResponse<SupportTicket>>(
      `${this.baseUrl}/category/${encodeURIComponent(category)}`,
      { params }
    );
  }

  searchItems(
    keyword: string,
    page: number,
    size: number
  ): Observable<PagedResponse<SupportTicket>> {
    const params = new HttpParams().set('keyword', keyword).set('page', page).set('size', size);
    return this.http.get<PagedResponse<SupportTicket>>(`${this.baseUrl}/search`, { params });
  }

  getCategories(): Observable<string[]> {
    return this.http.get<string[]>(`${this.baseUrl}/categories`);
  }

  createItem(item: SupportTicket): Observable<SupportTicket> {
    return this.http.post<SupportTicket>(this.baseUrl, item);
  }

  updateItem(id: number, item: SupportTicket): Observable<SupportTicket> {
    return this.http.put<SupportTicket>(`${this.baseUrl}/${id}`, item);
  }

  patchItem(id: number, changes: Partial<SupportTicket>): Observable<SupportTicket> {
    return this.http.patch<SupportTicket>(`${this.baseUrl}/${id}`, changes);
  }

  deleteItem(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
