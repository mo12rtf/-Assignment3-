import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Custom validator: rejects values that are empty or contain only
 * white space. Validators.required alone lets "   " through, so this
 * closes that gap for text fields (title, code).
 */
export function noWhitespaceValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (value == null) {
      return null;
    }
    const isWhitespaceOnly = value.toString().trim().length === 0 && value.toString().length > 0;
    return isWhitespaceOnly ? { whitespace: true } : null;
  };
}

/**
 * Custom business-rule validator (form-level): a ticket marked URGENT
 * needs at least 2 estimated hours, since a same-minute fix would not
 * realistically be flagged urgent. This is distinct from the plain
 * min/max range check, which only guards the 1-100 bound.
 */
export function urgentPriorityMinHoursValidator(): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const priority = group.get('priority')?.value;
    const hours = group.get('estimatedHours')?.value;
    if (priority === 'URGENT' && hours != null && hours < 2) {
      return { urgentNeedsMoreHours: true };
    }
    return null;
  };
}
