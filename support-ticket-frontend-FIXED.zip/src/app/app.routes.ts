import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'tickets' },

  {
    path: 'tickets',
    loadComponent: () =>
      import('./features/tickets/ticket-list/ticket-list.component').then(
        (m) => m.TicketListComponent
      ),
    canActivate: [authGuard]
  },
  {
    path: 'tickets/category/:category',
    loadComponent: () =>
      import('./features/tickets/ticket-list/ticket-list.component').then(
        (m) => m.TicketListComponent
      ),
    canActivate: [authGuard]
  },
  {
    path: 'tickets/search/:keyword',
    loadComponent: () =>
      import('./features/tickets/ticket-list/ticket-list.component').then(
        (m) => m.TicketListComponent
      ),
    canActivate: [authGuard]
  },
  {
    path: 'tickets/detail/:id',
    loadComponent: () =>
      import('./features/tickets/ticket-detail/ticket-detail.component').then(
        (m) => m.TicketDetailComponent
      ),
    canActivate: [authGuard]
  },
  {
    path: 'tickets/add',
    loadComponent: () =>
      import('./features/tickets/ticket-form/ticket-form.component').then(
        (m) => m.TicketFormComponent
      ),
    canActivate: [authGuard, roleGuard],
    data: { roles: ['MANAGER', 'ADMIN'] }
  },
  {
    path: 'tickets/edit/:id',
    loadComponent: () =>
      import('./features/tickets/ticket-form/ticket-form.component').then(
        (m) => m.TicketFormComponent
      ),
    canActivate: [authGuard, roleGuard],
    data: { roles: ['MANAGER', 'ADMIN'] }
  },

  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login/login.component').then((m) => m.LoginComponent)
  },

  {
    path: 'access-denied',
    loadComponent: () =>
      import('./shared/access-denied/access-denied.component').then(
        (m) => m.AccessDeniedComponent
      )
  },

  {
    path: '**',
    loadComponent: () =>
      import('./shared/page-not-found/page-not-found.component').then(
        (m) => m.PageNotFoundComponent
      )
  }
];
