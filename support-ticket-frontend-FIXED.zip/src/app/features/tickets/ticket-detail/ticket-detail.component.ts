import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { TicketService } from '../../../core/services/ticket.service';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SupportTicket } from '../../../core/models/ticket.model';
import { EstimatedHoursPipe } from '../../../core/pipes/estimated-hours.pipe';

@Component({
  selector: 'app-ticket-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, EstimatedHoursPipe],
  templateUrl: './ticket-detail.component.html',
  styleUrl: './ticket-detail.component.css'
})
export class TicketDetailComponent implements OnInit {
  ticket: SupportTicket | null = null;
  notFound = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private ticketService: TicketService,
    public auth: AuthService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id) {
      this.notFound = true;
      return;
    }

    this.ticketService.getItemById(id).subscribe({
      next: (ticket) => (this.ticket = ticket),
      error: () => (this.notFound = true)
    });
  }

  deleteTicket(): void {
    if (!this.ticket?.id) {
      return;
    }
    const confirmed = confirm(`Delete ticket "${this.ticket.title}"? This cannot be undone.`);
    if (!confirmed) {
      return;
    }
    this.ticketService.deleteItem(this.ticket.id).subscribe({
      next: () => {
        this.notifications.success('Ticket deleted.');
        this.router.navigate(['/tickets']);
      }
    });
  }
}
