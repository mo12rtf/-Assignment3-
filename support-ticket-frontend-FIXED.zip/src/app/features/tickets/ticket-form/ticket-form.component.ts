import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { TicketService } from '../../../core/services/ticket.service';
import { NotificationService } from '../../../core/services/notification.service';
import {
  TICKET_CATEGORIES,
  TICKET_PRIORITIES,
  TICKET_STATUSES
} from '../../../core/models/ticket.model';
import {
  noWhitespaceValidator,
  urgentPriorityMinHoursValidator
} from '../../../core/validators/ticket-validators';

@Component({
  selector: 'app-ticket-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './ticket-form.component.html',
  styleUrl: './ticket-form.component.css'
})
export class TicketFormComponent implements OnInit {
  readonly categories = TICKET_CATEGORIES;
  readonly priorities = TICKET_PRIORITIES;
  readonly statuses = TICKET_STATUSES;

  isEditMode = false;
  ticketId: number | null = null;
  loadError = false;

  form!: ReturnType<FormBuilder['group']>;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private ticketService: TicketService,
    private notifications: NotificationService
  ) {
    this.form = this.fb.group(
      {
        title: ['', [Validators.required, noWhitespaceValidator()]],
        code: ['', [Validators.required, noWhitespaceValidator(), Validators.pattern(/^[A-Z]{3}-\d{3}$/)]],
        category: ['', [Validators.required]],
        estimatedHours: [1, [Validators.required, Validators.min(1), Validators.max(100)]],
        priority: ['MEDIUM', [Validators.required]],
        status: ['OPEN', [Validators.required]],
        active: [true]
      },
      { validators: urgentPriorityMinHoursValidator() }
    );
  }

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');

    if (idParam) {
      this.isEditMode = true;
      this.ticketId = Number(idParam);

      this.ticketService.getItemById(this.ticketId).subscribe({
        next: (ticket) => {
          this.form.patchValue({
            title: ticket.title,
            code: ticket.code,
            category: ticket.category,
            estimatedHours: ticket.estimatedHours,
            priority: ticket.priority,
            status: ticket.status,
            active: ticket.active
          });
        },
        error: () => (this.loadError = true)
      });
    }
  }

  get f() {
    return this.form.controls;
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();
    const payload = {
      title: value.title!,
      code: value.code!,
      category: value.category!,
      estimatedHours: value.estimatedHours!,
      priority: value.priority!,
      status: value.status!,
      active: value.active!
    };

    const request$ =
      this.isEditMode && this.ticketId
        ? this.ticketService.updateItem(this.ticketId, payload)
        : this.ticketService.createItem(payload);

    request$.subscribe({
      next: () => {
        this.notifications.success(this.isEditMode ? 'Ticket updated.' : 'Ticket created.');
        this.router.navigate(['/tickets']);
      }
    });
  }
}
