import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { TicketService } from '../../../core/services/ticket.service';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { SupportTicket } from '../../../core/models/ticket.model';
import { CategoryMenuComponent } from '../category-menu/category-menu.component';
import { TicketSearchComponent } from '../ticket-search/ticket-search.component';

type ListMode = 'all' | 'category' | 'search';

@Component({
  selector: 'app-ticket-list',
  standalone: true,
  imports: [CommonModule, RouterLink, CategoryMenuComponent, TicketSearchComponent],
  templateUrl: './ticket-list.component.html',
  styleUrl: './ticket-list.component.css'
})
export class TicketListComponent implements OnInit, OnDestroy {
  tickets: SupportTicket[] = [];
  page = 0;
  size = 10;
  totalElements = 0;
  totalPages = 0;

  mode: ListMode = 'all';
  activeCategory: string | null = null;
  activeKeyword: string | null = null;

  readonly pageSizeOptions = [5, 10, 20];

  private routeSub?: Subscription;

  constructor(
    private route: ActivatedRoute,
    private ticketService: TicketService,
    public auth: AuthService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    this.routeSub = this.route.paramMap.subscribe((params) => {
      const category = params.get('category');
      const keyword = params.get('keyword');

      this.activeCategory = category;
      this.activeKeyword = keyword;
      this.mode = category ? 'category' : keyword ? 'search' : 'all';

      // A new filter always starts back at page 0.
      this.page = 0;
      this.load();
    });
  }

  ngOnDestroy(): void {
    this.routeSub?.unsubscribe();
  }

  load(): void {
    const request$ =
      this.mode === 'category' && this.activeCategory
        ? this.ticketService.getItemsByCategory(this.activeCategory, this.page, this.size)
        : this.mode === 'search' && this.activeKeyword
          ? this.ticketService.searchItems(this.activeKeyword, this.page, this.size)
          : this.ticketService.getItems(this.page, this.size);

    request$.subscribe({
      next: (result) => {
        this.tickets = result.content;
        this.totalElements = result.totalElements;
        this.totalPages = result.totalPages;
      },
      error: () => {
        this.tickets = [];
      }
    });
  }

  changePage(newPage: number): void {
    if (newPage < 0 || newPage >= this.totalPages) {
      return;
    }
    this.page = newPage;
    this.load();
  }

  changePageSize(newSize: number): void {
    this.size = newSize;
    this.page = 0;
    this.load();
  }

  deleteTicket(ticket: SupportTicket): void {
    if (!ticket.id) {
      return;
    }
    const confirmed = confirm(`Delete ticket "${ticket.title}"? This cannot be undone.`);
    if (!confirmed) {
      return;
    }
    this.ticketService.deleteItem(ticket.id).subscribe({
      next: () => {
        this.notifications.success('Ticket deleted.');
        this.load();
      }
    });
  }
}
