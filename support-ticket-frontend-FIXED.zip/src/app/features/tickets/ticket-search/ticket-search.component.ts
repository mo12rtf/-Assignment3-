import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ticket-search',
  standalone: true,
  templateUrl: './ticket-search.component.html',
  styleUrl: './ticket-search.component.css'
})
export class TicketSearchComponent {
  constructor(private router: Router) {}

  // Uses a template reference variable rather than ngModel: this box is a
  // simple one-way action (navigate to a route), not part of the
  // create/update entity form, which is the only form required to be
  // built with Reactive Forms.
  search(input: HTMLInputElement): void {
    const trimmed = input.value.trim();
    if (trimmed.length === 0) {
      this.router.navigate(['/tickets']);
      return;
    }
    this.router.navigate(['/tickets/search', trimmed]);
  }
}
