import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-page-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container py-5 text-center">
      <h1 class="display-4">404</h1>
      <p class="lead">This page does not exist.</p>
      <a routerLink="/tickets" class="btn btn-primary">Back to tickets</a>
    </div>
  `
})
export class PageNotFoundComponent {}
