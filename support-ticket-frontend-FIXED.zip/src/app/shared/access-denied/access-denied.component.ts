import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-access-denied',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container py-5 text-center">
      <h1 class="display-5 text-danger">Access denied</h1>
      <p class="lead">Your role does not have permission to view this page.</p>
      <a routerLink="/tickets" class="btn btn-primary">Back to tickets</a>
    </div>
  `
})
export class AccessDeniedComponent {}
