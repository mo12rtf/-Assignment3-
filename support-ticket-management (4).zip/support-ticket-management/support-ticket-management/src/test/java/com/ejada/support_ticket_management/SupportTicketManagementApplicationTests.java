package com.ejada.support_ticket_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportTicketManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
