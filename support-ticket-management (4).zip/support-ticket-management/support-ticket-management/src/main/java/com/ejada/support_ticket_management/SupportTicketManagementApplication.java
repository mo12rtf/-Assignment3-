package com.ejada.support_ticket_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupportTicketManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupportTicketManagementApplication.class, args);
	}

}
