package com.ejada.support_ticket_management.service;

public interface NotificationService {

    void sendNotification(String message);

}