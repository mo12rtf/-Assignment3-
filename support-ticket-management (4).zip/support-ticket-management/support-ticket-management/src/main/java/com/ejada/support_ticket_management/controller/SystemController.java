package com.ejada.support_ticket_management.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SystemController {

    @Value("${training.system.name}")
    private String systemName;

    @GetMapping("/system-name")
    public String getSystemName() {

        return systemName;

    }
}
