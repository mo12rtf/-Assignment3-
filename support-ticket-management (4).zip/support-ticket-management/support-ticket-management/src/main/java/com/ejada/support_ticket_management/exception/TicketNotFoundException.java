package com.ejada.support_ticket_management.exception;

public class TicketNotFoundException
        extends RuntimeException {

    public TicketNotFoundException(String message) {

        super(message);

    }

}