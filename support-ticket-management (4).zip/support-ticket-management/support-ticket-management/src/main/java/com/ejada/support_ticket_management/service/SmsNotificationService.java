package com.ejada.support_ticket_management.service;

import org.springframework.stereotype.Service;

@Service
public class SmsNotificationService implements NotificationService {

    @Override
    public void sendNotification(String message) {

        System.out.println("SMS: " + message);

    }

}