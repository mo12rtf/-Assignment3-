package com.ejada.support_ticket_management.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/tickets-page")
    public String ticketsPage() {

        return "tickets";

    }

    @GetMapping("/ticket-form")
    public String ticketForm() {

        return "ticket-form";

    }

}