package com.ejada.support_ticket_management.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Value("${training.system.name}")
    private String systemName;

    @Bean
    public String systemNameBean() {

        return systemName;

    }
}
