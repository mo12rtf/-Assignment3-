package com.ejada.support_ticket_management.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ejada.support_ticket_management.entity.SupportTicket;

@Repository
public interface SupportTicketRepository
        extends JpaRepository<SupportTicket, Long> {

    List<SupportTicket> findByCategory(String category);

    Page<SupportTicket> findByCategory(String category, Pageable pageable);

    Page<SupportTicket> findByTitleContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrCodeContainingIgnoreCase(
            String title, String category, String code, Pageable pageable);

    @Query("select distinct t.category from SupportTicket t where t.category is not null order by t.category")
    List<String> findDistinctCategories();

}
