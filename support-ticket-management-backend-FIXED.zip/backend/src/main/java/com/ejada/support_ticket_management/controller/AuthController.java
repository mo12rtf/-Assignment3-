package com.ejada.support_ticket_management.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * There is no separate /login endpoint because authentication is done via
 * HTTP Basic on every request. The Angular LoginComponent instead sends the
 * entered credentials as a Basic Authorization header to GET /api/auth/me:
 * a 200 response with {username, role} means the credentials are valid and
 * tells the front end which role to store for its route guards; a 401
 * means the credentials were rejected.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @GetMapping("/me")
    public Map<String, String> me(Authentication authentication) {

        String role = authentication.getAuthorities().stream()
                .findFirst()
                .map(GrantedAuthority::getAuthority)
                .orElse("")
                .replace("ROLE_", "");

        Map<String, String> response = new HashMap<>();
        response.put("username", authentication.getName());
        response.put("role", role);
        return response;
    }
}
