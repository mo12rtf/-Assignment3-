package com.ejada.support_ticket_management.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ejada.support_ticket_management.entity.AppUser;
import com.ejada.support_ticket_management.repository.AppUserRepository;

/**
 * Seeds the three test accounts (employee / manager / admin) into the
 * database on first startup, so authentication is genuinely database-backed
 * instead of an in-memory list. Passwords are bcrypt-hashed, never stored
 * in plain text. Safe to run on every startup: it only inserts users that
 * do not already exist.
 */
@Configuration
public class DataSeeder {

    @Bean
    public CommandLineRunner seedUsers(
            AppUserRepository repository,
            PasswordEncoder passwordEncoder) {

        return args -> {

            createIfMissing(repository, passwordEncoder,
                    "employee", "1234", "EMPLOYEE");

            createIfMissing(repository, passwordEncoder,
                    "manager", "1234", "MANAGER");

            createIfMissing(repository, passwordEncoder,
                    "admin", "1234", "ADMIN");
        };
    }

    private void createIfMissing(
            AppUserRepository repository,
            PasswordEncoder passwordEncoder,
            String username,
            String rawPassword,
            String role) {

        if (repository.findByUsername(username).isEmpty()) {
            AppUser user = new AppUser(
                    username,
                    passwordEncoder.encode(rawPassword),
                    role);
            repository.save(user);
        }
    }
}
