package com.ejada.support_ticket_management.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ejada.support_ticket_management.dto.PagedResponse;
import com.ejada.support_ticket_management.entity.SupportTicket;
import com.ejada.support_ticket_management.exception.TicketNotFoundException;
import com.ejada.support_ticket_management.repository.SupportTicketRepository;

@Service
public class SupportTicketService {

    private final SupportTicketRepository repository;
    private final NotificationService notificationService;

    public SupportTicketService(
            SupportTicketRepository repository,
            NotificationService notificationService) {

        this.repository = repository;
        this.notificationService = notificationService;
    }

    public PagedResponse<SupportTicket> getAllTickets(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<SupportTicket> result = repository.findAll(pageable);
        return new PagedResponse<>(result);

    }

    public SupportTicket getTicketById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new TicketNotFoundException(
                                "Ticket not found with id: " + id));

    }

    public PagedResponse<SupportTicket> getTicketsByCategory(
            String category, int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<SupportTicket> result =
                repository.findByCategory(category, pageable);
        return new PagedResponse<>(result);

    }

    public PagedResponse<SupportTicket> searchTickets(
            String keyword, int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<SupportTicket> result = repository
                .findByTitleContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrCodeContainingIgnoreCase(
                        keyword, keyword, keyword, pageable);
        return new PagedResponse<>(result);

    }

    public List<String> getCategories() {

        return repository.findDistinctCategories();

    }

    public SupportTicket createTicket(SupportTicket ticket) {

        notificationService.sendNotification(
                "New Ticket Created");

        return repository.save(ticket);

    }

    public SupportTicket updateTicket(
            Long id,
            SupportTicket updatedTicket) {

        SupportTicket ticket = repository.findById(id)
                .orElseThrow(() ->
                        new TicketNotFoundException(
                                "Ticket not found with id: " + id));

        ticket.setTitle(updatedTicket.getTitle());
        ticket.setCategory(updatedTicket.getCategory());
        ticket.setEstimatedHours(updatedTicket.getEstimatedHours());
        ticket.setPriority(updatedTicket.getPriority());
        ticket.setStatus(updatedTicket.getStatus());
        ticket.setActive(updatedTicket.isActive());
        ticket.setCode(updatedTicket.getCode());

        return repository.save(ticket);

    }

    public SupportTicket patchTicket(
            Long id,
            SupportTicket updatedTicket) {

        SupportTicket ticket = repository.findById(id)
                .orElseThrow(() ->
                        new TicketNotFoundException(
                                "Ticket not found with id: " + id));

        if (updatedTicket.getTitle() != null) {
            ticket.setTitle(updatedTicket.getTitle());
        }

        if (updatedTicket.getCategory() != null) {
            ticket.setCategory(updatedTicket.getCategory());
        }

        if (updatedTicket.getPriority() != null) {
            ticket.setPriority(updatedTicket.getPriority());
        }

        if (updatedTicket.getStatus() != null) {
            ticket.setStatus(updatedTicket.getStatus());
        }

        if (updatedTicket.getCode() != null) {
            ticket.setCode(updatedTicket.getCode());
        }

        if (updatedTicket.getEstimatedHours() != 0) {
            ticket.setEstimatedHours(updatedTicket.getEstimatedHours());
        }

        ticket.setActive(updatedTicket.isActive());

        return repository.save(ticket);

    }

    public void deleteTicket(Long id) {

        if (!repository.existsById(id)) {
            throw new TicketNotFoundException(
                    "Ticket not found with id: " + id);
        }

        repository.deleteById(id);

    }
}
