package com.ejada.support_ticket_management.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ejada.support_ticket_management.dto.PagedResponse;
import com.ejada.support_ticket_management.entity.SupportTicket;
import com.ejada.support_ticket_management.service.SupportTicketService;

@RestController
public class SupportTicketController {

    private final SupportTicketService service;

    public SupportTicketController(
            SupportTicketService service) {

        this.service = service;
    }

    @GetMapping("/api/tickets")
    public PagedResponse<SupportTicket> getAllTickets(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return service.getAllTickets(page, size);

    }

    @GetMapping("/api/tickets/{id}")
    public SupportTicket getTicketById(
            @PathVariable Long id) {

        return service.getTicketById(id);

    }

    @GetMapping("/api/tickets/category/{category}")
    public PagedResponse<SupportTicket> getTicketsByCategory(
            @PathVariable String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return service.getTicketsByCategory(category, page, size);

    }

    @GetMapping("/api/tickets/search")
    public PagedResponse<SupportTicket> searchTickets(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return service.searchTickets(keyword, page, size);

    }

    @GetMapping("/api/tickets/categories")
    public List<String> getCategories() {

        return service.getCategories();

    }

    @PostMapping("/api/tickets")
    public SupportTicket createTicket(
            @Valid @RequestBody SupportTicket ticket) {

        return service.createTicket(ticket);

    }

    @PutMapping("/api/tickets/{id}")
    public SupportTicket updateTicket(
            @PathVariable Long id,
            @Valid @RequestBody SupportTicket ticket) {

        return service.updateTicket(id, ticket);

    }

    @PatchMapping("/api/tickets/{id}")
    public SupportTicket patchTicket(
            @PathVariable Long id,
            @RequestBody SupportTicket ticket) {

        return service.patchTicket(id, ticket);

    }

    @DeleteMapping("/api/tickets/{id}")
    public void deleteTicket(
            @PathVariable Long id) {

        service.deleteTicket(id);

    }

}
